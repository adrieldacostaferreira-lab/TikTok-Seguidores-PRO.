TikTok Seguidores PRO - projeto Android

Este é o projeto-fonte Android (WebView) com a demonstração incluída em assets.
Não é um APK compilado.

Como gerar o APK:
1. Instale Android Studio em um computador.
2. Abra a pasta TikTokSeguidoresPRO_Android no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de debug será gerado em app/build/outputs/apk/debug/app-debug.apk.

A demonstração mantém dados localmente no aparelho. Não automatiza seguidores,
curtidas ou comentários e não pede senha do TikTok.
